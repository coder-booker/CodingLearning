# General
- 总线分为数据、地址、控制三条
- 地址总线的数量会限制其能够访问的内存。如32条总线只能操作4G内存，因为4G的内存一共有2^32的地址

- cpu运行逻辑
    - 访问pc，准备代码和数据->解析内容并运行->pc自增，再准备新数据
- 指令的类型
    - 运算、传输数据、跳转、信号（例如中断）、闲置（nop）

# 缓存
- SRAM：用于缓存，断电就没
- DRAM：用于内存和显存，因为用了电容所以要定期刷新，但断电还是没
- L1：为core-exclusive，但分为指令和数据缓存两种
- L2：为core-exclusive，不分指令和数据
- L3：多核共享
- 缓存块（cache line/block）
    - 组标记（标记同索引下时这是哪个块，因为多个内存块可以映射到一个索引），索引（指向内存块），偏移量
- 内存：没啥好说的，最多就是虚拟内存管理和与硬盘swap而已（这也是每个硬盘可以设置虚拟内存空间的原因）
- 多核缓存同步
    - 两个重点：
        - 写传播：把变化传播到别的核心
        - 事务串行化：队列或者锁就是干这个的，让变化的顺序可以预测
    - solutions
        - 总线嗅探（bus snooping），但非常低效
        - MESI
            - 重要概念：自己和别人的read和write
            - M：modified
                - 采用写回（有需要时才写回内存）
                - 如果被外部read了就写回和S
                - 如果被外部write了就写回和I
            - E：exclusive
                - 只有自己read了这个数据就会E
                - 如果自己write了就M
                - 如果别人read就S
                - 如果别人write了就I
            - S：shared
                - 多核共用数据时S
                - 自己write了就M，其他S变成I
                - 别人write了就自己变成I
            - I：Invalid
                - 无数据或者无效数据
                - 独占read则E，多人read则S，有人M则读取内存和与那个人S
                - 独占write则缓存并M，有人则按上面的规则改变他们的状态（如M写回，S/E变I）
- 特殊内容：
    - 伪共享：
        - 同一line内不同数据被修改，哪怕这些数据不是同一位都会导致这line被不停写回，和没cache一样
        - solution：、
            - 对于需要频繁修改的数据：有些指令可以把指定数据对齐cache line而非排在同一line上
            - 对于不会频繁修改的数据：前置填充和后置填充，让数据所map到的cache line（可能多过一个）一定不会和其他东西共用line

# 进程线程（只要没指名，都是在说linux内核的规则）
- 进程和线程都以task_struct结构体表示
- 有三种 调度类 | 调度器 | 调度策略 | 运行队列（Run Queue）
    - Deadline | Deadline调度器 | SCHED_DEADLINE | dl_rq
        - 以ddl近为优先
    - Realtime | RT调度器 | SCHED_FIFO/_RR | rt_rq
        - _FIFO：以任务为最小单位的优先队列(也就是完成了任务才换下一个)，有优先度的设定可以插队
        - _RR：以时间片为最小单位的优先队列，有优先度设定可以插队
    - Fair | CFS 调度器 | SCHED_NORMAL/_BATCH | cfs_rq
        - 都是完全公平调度CFS（Completely Fair Schedule）
            - 以一个动态的量vruntime为标准分配任务，vruntime越少就越先跑
                - 任务每次运行都会更新其vruntime:vruntime += delta_exec* NICE_0_LOAD/权重
                    - delta_exec：实际运行时间
                    - NICE_0_LOAD差不多是个常量
                    - 每个任务都有自己的权重
                    - 所以vruntime就是实际运行时间经由权重和NICE值映射后的虚拟运行时间，越短，在电脑的角度来看就就代表越少被运行，就会更容易被调度
        - _NORMAL：用于前台普通任务
        - _BATCH：用于后台普通任务
- 运行队列顺序：dl_rq > rt_rq > cfs_rq
- dl和rt用于实时任务，cfs用于普通任务
- 优先级分配
    - 0-139个优先级
        - 0-99是实时任务的
        - 100-139是普通任务的
    - 优先级越小越高
    - nice值为-20-19这个区间，也就是普通任务从中间往左右走的优先级
    - linux可以用`nice -n -[nice值] [task]`和`renice -[nice值] -p [进程pid]`来设置task的优先级
- 调度策略分配：linux可以用`chrt -[调度策略] [优先级] -p [pid]`来改变调度策略

- 中断
    - 硬中断->软中断
    - 流程：
        - 对于一个需要中断的任务，例如回调任务，会先硬件中断让cpu该任务必须先完成的部分完成（例如超时了就会消失的时间敏感数据）
        - 等cpu搞定了目前的事儿，就回过头来软中断，把任务以线程的方式塞给cpu
    - 具体一个任务怎么划分硬中断和软中断则由os自己hardcode决定
        - eg 网卡有数据，硬中断会叫cpu把网卡数据先存入内存，软中断则会让cpu开始拆包解析网卡的数据
    - 指令
        - `/proc/interrupts`可以得到硬中断情况
        - `/proc/softirqs`可以得到cpu核的各类总中断次数
        - 而软中断的线程则可以通过ps找到
            - `ps aux | grep softirq`：这个指令会得到一堆有`[ksoftirqd/0]`标识的线程，代表kernel soft interrupt，斜杠后的数字是cpu core的索引


下一步是精度问题
