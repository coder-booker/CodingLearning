# Experience
- RESTful的抓包和破解尝试（包括更改url（path和query string），更改body，更改method等）
- 查看html的hidden项
- 同级和向上的入侵，尝试权限修改
- 除了手动猜测之外，也要利用好网站自己就暴露出来的功能
- 攻击者一般是在没有任何session的情况下尝试攻击的，因此有session的情况下很多防御手段都会无效化


### CIA + AAN
- CIA
    - Confidentiality
        - 资源保护，未授权不能获得某些资源
    - Integrity
        - 完整性，也就是数据应该一致，不能随意更改
    - Availability
        - 字面意思，服务器烧了，着火了都算不available
- AAN
    - Authentication
        - identify who you are
    - Authorisation
        - give function based on who you are
    - Non-repudiation
        - 不可否认性：用唯一的数字签名来标识发送方
        - 为了让数据也拥有法律效力

# Broken Access Control
- types:
    - Insecure Direct Object Reference (IDOR)
        - types：
            - Path traversal: url path的直接引用获取
                - 尝试直接访问后端端口
                - 尝试遍历更改query string来获取资料（甚至直接写'../../../sys.ini'）
            - JWT, tickets这类的单一验证
    - Cross-Site Request Forgery (CSRF)
        - elevation of privilege
        - 常见于只使用session和其cookies来验证的网站
        - 成功提升后要记得更新session
- experience
    - 从抓包中找到些资讯，然后尝试用在url上作为param或者query string
# Hash
- most commonly used algorithm
    - MD5
    - SHA256
- hash是可能被破解的，用些hash的识别网站就有可能
    - URL modifying
- cookie

# injection
- 有很多种
    - cross site scripting (XSS)
        - 在受害者网站内运行script/code
        - three types:
            - Reflected XSS (non-persistent XSS attack)
                - 在http请求中嵌入代码，如在query string写&lt;script>
                - non-persistent是因为只有那一种情况会运行恶意代码
            - Stored XSS（persistent XSS attack）
                - 把有害代码通过某种方式保存到app里，每当app的这个功能被触发就会触发有害代码
                - e.g. 在comment中插入script，只要有用户加载了这条评论就会运行script
            - DOM-based XSS
                - 和reflected XSS很像，但不使用http来攻击，而是用响应式js的动态DOM来运行恶意代码
                - 因此在服务端没法识别到这种攻击，因为往服务端发的http请求中没有痕迹
    - XML external entity injection (XXE) 
        - 在接收XML的应用服务中，利用XXE语言的特性来获得敏感信息
    - OS injection
        - 直接在服务端的os运行代码
        - 例如参数传到linux中并运行某命令，用;或者&&来在那一条行中运行多条命令
- 一些防范的手段：
    - cookie设置HttpOnly
    - CSRF token：动态生成会话唯一的token来标识合法http请求



# useful vocab
- privilege
- RBAC（Role-Based Access Control，基于角色的访问控制）
- audit 审核
- exploit 恶意利用