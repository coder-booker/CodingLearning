# 同源策略 Same-Origin Policy (SOP)
- 协议|域名|端口 不同的请求地址不能交叉请求
- 为了防止源读取另一个源中的用户得到的响应信息所建立的策略

# 出站入站ip
- 出站就是本地访问外部时本地发出的source ip
- 入站就是外部访问本地地目标ip

# Cookie
- 每次请求都会把当前域名下的cookie发送出去

# CSR, SSR, SSG, ISR
- CSR: Client Side Rendering 
    - 仅接受html文档，然后自己渲染
- SSR: Server Side Rendering 
    - 服务器帮你把html文档渲染好，返回一个类似数据流的渲染完成的html
- SSG: Static Site Generation
    - 用户磁盘保存
- ISR: Incremental Site Rendering
    - SSG，但是根据使用情况（例如热度）异步更新到CDN服务器
- others: 
    - CDN: Content Delivery Network或Content Distribution Network, 就是当地服务器在主服务器前的缓存用服务器
    - html文档和渲染是分开的。

# TLS
- HTTPS 用的加密协议
- 前身为SSL协议
- TLS证书就是域所有者在所有TLS协议中的公钥
- TLS流程（用户与服务器之间）：
    - 指定将要使用的 TLS 版本（TLS 1.0、1.2、1.3 等）
    - 决定将要使用哪些密码套件
    - 使用服务器的 TLS 证书验证服务器的身份
    - 握手完成后，生成会话密钥用于加密两者之间的消息
- TLS 1.3 中的 TLS 握手仅需要一次往返（即来回通信），而不是以前的两次，将握手过程所需时间缩短了几毫秒
- Cloudflare 向所有用户提供免费的 TLS/SSL 证书
- *********由于历史遗留原因（人们已经用ssl很久了），tls配置很多时候仍会使用ssl作命名，但实际上命名为ssl的东西基本上都同时支持tls了

# stateless
- 服务器无状态，也就是所有请求之间都没有关系，没有session资料会保存在服务器
    - 如果是前后端分离的话，restful本身就是stateless的，状态都在前端
# serverless
- 云服务部署就是serverless

# session & cookie
### session
- 一个用户一个session，用来作为管理资源和状态的最小单位
- 一般对于session的管理都在服务端，以session_id的形式储存在cookie并每次都发给服务端
### cookie
- 一坨在客户端的键值对，用来进行状态管理的
- HTTPOnly属性：只有http请求能够获得这个cookie，js无法获得（XSS无法获得）
- SameSite属性：用以限制跨站请求
    - Strict：所有跨站请求都不会发送该cookie
    - Lax：部分跨站请求才会发送该cookie
    - None：所有跨站请求都会发送该cookie

# JWT (JSON Web Token)
- 把json格式的用户信息转换为token的某个方法，并不是用来传输json的安全方法
- 一种跨域认证方法，本质上就是把所有用户信息都映射(加密)成一份乱码字符串(加密的东西一般都类似乱码)，保存在用户本地
- 访问服务器时把JWT发给服务器就可以让服务器决定对应行为，例如没过期的话就不用重新登陆、允许跨域等
- 创建用参数，创建好之后命名为payload：
    - sub=uuid: 唯一标识符，用来表明主题的
    - exp=int(timestamp): 过期时间, timestamp
    - nbf=int(timestamp): not before. 生效时间, timestamp
    - iat=int(timestamp): issue at, 签发时间, timestamp
    - iss=ISSUER: issuer, 签发者, string/URI
    - aud=audience: audience, 预期接收者, string/URI
- 加密用参数，创建好之后命名为token并发送给客户端: 
    - payload=Dict: payload一般就是创建好的jwt对象，这里要转成dict或者json
    - key=SECRET_KEY: 密钥
    - algorithm='HS256': 加密算法
- 解密用参数，创建好之后变回payload: 
    - jwt=token: jwt token
    - key=SECRET_KEY: 密钥
    - algorithm='HS256': 加密算法
    - issuer=ISSUER
    - audience=audience,  # 令牌的预期接收者



# RESTful
- body, query string, params
- body: 
    - 一般是比较复杂或者庞大的数据，例如多条字段，大文件等
- query string: 
    - url后用`?`标识
    - 一般给GET或者DELETE用
    - 一般用于查询某个资源
- params:
    - url后以params为子路径
- 幂等
    - 同一条http请求，每次执行的结果对资源来说都和第一次一样
- POST VS PUT
    - POST：
        - 创建或提交(表单/数据)
        - 一般用于生成数据，因此不一定指向一个目标，，因此不幂等
    - PUT：
        - 创建或更新资源
        - 是幂等的，因为每次使用都必须指定一个目标




# theory stuff
- to-learn: 
    - TCP和UDP请求的结构
- UDP
    - checksum具体的原理？
- seq_num
    - 其实会不停循环分配，不然会overflow
    - 值得一提的是window size和seq_num有关联，具体在于类似哈希的避免同一个window中出现了相同的seq_num，因此seq_num要大于window size*2

- TCP
    - 使用四个元素识别一条链接：
        - 源IP、目标IP、源端口、目标端口
    - 三次握手
        - 流程
            - 发送方SYN请求
            - 接收方收到SYN，发送SYNACK
            - 发送方接收到SYNACK，发送ACK
        - 如果任何包丢失了，都会触发超时重传
        - 任何原因接收到了重复的包，都会重新发送对应的回复包
            - 如发送方syn丢失，发送方一定时间没接收到synack就会再发syn
            - 如接收方synack丢失or发送方ack丢失，接收方一定时间没接收到ack就会再发synack
    - 发送数据（重传、流量控制）
        - seq_num来标识不同数据包
        - 发送方和接收方会有缓存，因此只需要重发/重复ACK特定的那个序列号就行
        - 接收方哪怕接到了重复的包，也会照样发ACK，只发一两次也不会触发快速重传
        - 注意ACK的确认序列是发送方的序列+1单位
        - 缓存不能过小到倒计时重传/快速重传都还没触发就溢出了
        - 默认使用累计ACK
            - 在一个延迟ACK内如果没有接收到下一个包，就ACK，反之则重新倒数延迟ACK
            - 如果在没有触发延迟ACK的情况下接收到了足够多的包，也会发送ACK。
        - 在以下特殊情况切换为立刻ACK
            - 接收方收到乱序数据包，就会立刻ACK最后一个按顺序的包
            - 接收窗口满了，立刻ACK。（和累计ACK的数据包数量没啥关系）
            - 数据段包含PUSH标志（发送方手动要求直接ACK）
            - 数据段包含FIN标志（发送方请求终止连接）
            - Nagle算法（？）
        - 快速重传
            - 出现三次重复ACK的时候，重传。而在三次之前发送方都仍然会继续发送
                - 一般是乱序了导致接收方立刻ACK，但因为实际上是丢包了导致的不停立刻ACK
                - 一方面是为了触发接收方的乱序立刻ACK，一方面是为了包容一到两个单位的包并没有丢只是乱序的情况
        - 超时重传
            - 和累计ACK地触发条件有关系（如果延迟ACK时间导致超时或者触发一次累计ACK的数据包数量太多导致超时）
            - 倒计时时的行为：
                - 发送方丢包：在倒计时时仍然会继续传，但因为接收方乱序，会缓存和立刻ACK。要么三次后快速重传，要么倒计时结束重传
                - 接收方丢包：后续的数据包在接收方看来是正确的，因此必然倒计时重传，而接收方只会发多一次ACK而已
        - 窗口更新（流量控制）
            - 为了应付buffer已满的情况而设置的特性
            - 窗口大小就是缓存空间可用的剩余大小，和包的大小没啥关系
            - 接收方的每次ACK都会包含窗口大小
            - 具体流程：
                - 接收方buffer(也就是窗口)满了时，忽略所有新包并发送窗口最后一个包的ACK，这个ACK的窗口大小为0
                - 发送方收到ACK并停止
                - 接收方在处理得差不多之后（看os的设置），发送新的窗口大小不为0的ACK
                - 发送方接收到该ACK，并按照其序列号继续发送
    - 四次握手连接终止
        - 由发送方起头，然后各自都发一次FIN和接受一次ACK
        - 具体流程：
            - 发送方：FIN（发送方再也无法主动发送，只能回复）
            - 接收方：ACK
            - 接收方：FIN（接收方再也无法主动发送，只能回复）（但也不需要回复了）
            - 发送方：ACK（接收方closed）
            - 等待2*segment_lifetime（发送方closed）
    - segment_lifetime
        - 约等于重传计时器时长
        - TTL(Time to Live)好像也会影响
### 缓存
- 通过设置header字段来实现
- 有两种，但第二种一般配合第一种使用；
    - 强制缓存
        - 有两种
            - Cache-Control（由Response设置）
                - 优先级比expire高，且选择更精细
                - 由Response的header设置
                - 包含了过期时间
            - Expires
    - 协商缓存
        - 协商缓存什么时候刷新缓存是由应用+浏览器+强制缓存的缓存策略决定的
            - 例如浏览器页面刷新或者应用要validate数据，就会重新请求资源而非读取缓存
        - 有两种
            - If-Modified-Since（Request设置）+ Last-Modified（Response设置）
                - 第一次后的所有请求都会把最近一次响应体的Last-Modified的值以If-Modified-Since字段发出
                - 服务器根据If-Modified-Since判断是否过期
                    - 没过期就304，过期了就发送新资源
                - Last-Modifed的时间精度大于等于秒级
            - If-None-Match（Request设置）+ ETag（Response设置）
                - 第一次后的所有请求都会把最近一次响应体的ETag的值以If-None-Match字段发出
                    - 服务器根据If-None-Match判断是否过期
                        - 没过期就304，过期了就发送新资源
                - ETag的时间精度在秒级以下
                - ETag的生成与文件内容、大小、版本号、修改时间有关，因此可以识别没有更新修改时间的修改
            - ETag和Last-Modified都被设置时，ETag没变化才对比Last-modified

# HTTP 
- 用换行符、回车符作为header每个项的边界
    - 一般是两个都用`\r\n`为项的结尾
    - `\r\n\r\n`标识所有header的结尾，下面就是body了
- 用Content-Legnth作为body的边界
### Header
- 常用header
    - HTTP/1.1 200 OK
    - Content-Type: 
        - json body: application/json
        - query string: application/x-www-form-urlencoded
            - e.g. 
            ```
            POST /getflag.php HTTP/1.1
            Host: 10.0.0.102
            User-Agent: Mozilla/5.0 (X11; Ubuntu; Linux x86_64; rv:131.0) Gecko/20100101 Firefox/131.0
            Accept: text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/png,image/svg+xml,*/*;q=0.8
            Accept-Language: en-US,en;q=0.5
            Accept-Encoding: gzip, deflate, br
            Content-Type: application/x-www-form-urlencoded
            Content-Length: 75
            Origin: http://10.0.0.102
            Connection: keep-alive
            Referer: http://10.0.0.102/message.php
            Cookie: PHPSESSID=a561bae723e2bf896352a27c9ee81917; Admin=Admin

            <!-- here is how the query string looks like in a http request -->
            csrf_token=d63e274d90a8cd33b1fac086669be5706f868a8b8bfc1b498e6bf449b774f2b9
            ```
        - 可以在分号加一个空格后append内容的编码格式
    - Content-Length: [length]
### HTTPS
- HTTP的缺陷
    - 会被窃听（抓包）
    - 会被篡改（修改请求和响应）
    - 会被冒充（假网站）
- 公钥，私钥
    - HTTPS的交流中存在公钥和私钥两个密钥
    - 一端加密，一段解密，因此可以用于验证客户端或者服务端身份
    - 是非对称加密，因此很消耗计算资源，因此只在SSL/TLS握手阶段才做
- 数字签名：
    - 用以让接收方验证发送方的身份
    - 具体流程
        - 对一段数据进行哈希运算
        - 用私钥加密
        - 把这段数据本身和加密上一步加密完的东西发出去
        - 接收方接收到数据和加密内容
        - 接收方用和发送方相同的哈希运算计算这段数据
        - 接收方公钥解密和这段数据一起发过来的加密内容
        - 对比接收方哈希出来的东西和公钥解密出来的东西
    - 所以本质上就是接受一段数据并哈希，然后对比和服务端的哈希是否一样。因为过程中用了私钥和公钥加密解密，因此如果私钥公钥不匹配，对比的东西必然有一段是不一样的。
- 数字证书
    - 记录在案（数字证书认证机构 CA）的证书，用来给客户端验证服务器身份用的。
    - 之所以记录在案是为了让HTTPS的confidentiality有法律效益
    - CA也有自己的私钥和公钥，目的是为了证明CA是CA。公钥一般都被各大浏览器内置
    - 具体内容：
        - 个人信息
        - 服务器的数字签名
        - 服务器私钥对应的公钥
        - CA对服务器公钥的数字签名
    - os和浏览器都会内置一些信任的证书来源
    - 证书信任链
        - 证书有根证书(root CA)的概念
        - 证书可以由不同的组织签发，但大部分都是嵌套的，目的是为了让一个根证书的失效不会影响所有证书
        - 服务端一般会把所有中间证书都发出来，如果没有则得从url中下载
        - 具体流程
            - 在收到一个证书之后，如果内置的根证书来源无法匹配最近的证书，就会去找该证书的签发者，其被称为中间证书，再次匹配
            - 不停往上溯源，直到找到匹配的根证书，就一层层往回验证中间证书，直到最近的那层也被验证成功
- 数据完整性验证（每次请求都会对内容进行完整性验证以防止篡改）
    - 重点在于消息认证码（MAC）
        - 用会话密钥哈希加密要发送的数据得到MAC

- 在TCP/IP层（网络传输层）和应用层之间加入一层SSL/TLS层
- 具体流程
    - SSL/TLS握手
        - 客户端向服务器发送一个握手请求
            - 包含支持的 SSL/TLS 版本、加密算法列表、生成的一个随机数。
        - 服务器响应握手请求
            - 确认SSL/TLS版本，选择一个加密算法，生成一个随机数，向客户端发送数字证书
        - 客户端回应
            - 验证服务器的数字证书
                - 客户端用内置的CA公钥解密出CA数字签名的服务器公钥
                - 对比服务器发来的公钥，如果相同就代表CA认证通过
                - 服务端一般会把所有中间证书都发出来
            - 客户端ACK（以下内容都会用服务器的公钥加密）
                - 再生成一个随机数
                - 通知服务端开始使用会话密钥
                - 生成之前所有握手数据的摘要供服务端校验
                - 通知服务端握手结束
            - 用前面生成的三个随机数和协商好的算法生成会话密钥，但这个密钥不会发出去
        - 服务器回应
            - 用前面生成的三个随机数和协商好的算法生成会话密钥，但这个密钥不会发出去
            - 服务端ACK（以下内容都会用服务器的私钥加密）
                - 通知客户端开始使用会话密钥
                - 生成之前所有握手数据的摘要供客户端校验
                - 通知客户端握手结束
        - 服务器使用私钥解密会话密钥，获得对称加密的会话密钥。
    - 服务端和客户端生成了相同的会话密钥，开始对称加密通信
        - 每次都会验证数据完整性
            - 具体流程
                - 发送方生成MAC
                - 把MAC集合在请求中正常会话加密发送给接收端
                - 接收端解密后得到MAC和数据
                - 以相同的哈希函数和会话密钥对数据生成对应MAC，如果和请求中的不用一样就代表数据可能被篡改过。相同则代表数据安全

- 几个问题
    - 4. 在传输过程中是用什么来验证数据完整性的？是MAC还是数字签名？


- HTTP和HTTPS的默认端口号不一样，一个80一个443
- HTTPS的优点
    - 加密了被窃听也没用
    - HTTPS有校验机制，请求和响应无法被篡改
    - HTTPS要获得数字证书，因此可以解决冒充的问题
### /1.0. /1.1, /2.0, /3.0
- /1.0
    - 短连接
- /1.1
    - 高度灵活，可以自定义和随意扩充
    - 长连接
    - pipeline（注意1.1时pipeline不是默认开启的）
    - stateless
    - 明文传输（但可以用SSL/TLS）
