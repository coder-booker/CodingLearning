# frame

### DTO, DAO, etc
- 订好前后端不同服务交互时的类定义